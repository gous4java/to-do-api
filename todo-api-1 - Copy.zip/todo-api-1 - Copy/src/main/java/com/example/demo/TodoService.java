package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TodoService {

    private final TodoRepository todoRepository;

    public TodoService(TodoRepository todoRepository) {
        this.todoRepository = todoRepository;
    }

    public List<Todo> getAllTodos(String username) {
        return todoRepository.findByName(username);
    }

    public Optional<Todo> getTodoById(String username, Long id) {
        return todoRepository.findByIdAndName(id, username);
    }

    public Todo createTodo(Todo todo) {
        return todoRepository.save(todo);
    }

    public Todo updateTodo(Long id, Todo todo) {

        Todo existingTodo = todoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Todo not found"));

        existingTodo.setName(todo.getName());
        existingTodo.setTodo(todo.getTodo());
        existingTodo.setDate(todo.getDate());
        existingTodo.setDone(todo.isDone());

        return todoRepository.save(existingTodo);
    }

    public void deleteTodo(Long id) {
        todoRepository.deleteById(id);
    }
}
